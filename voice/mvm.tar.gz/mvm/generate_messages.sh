#! /bin/sh
# generate_messages.sh -- Generate messages from textual representation
# Marc SCHAEFER <schaefer@alphanet.ch>
# Creation: 19/11/96
# Update:   06/04/97
# V1.0 PV003
# DISCLAIMER
#    No warranty, either expressed or implied.
# COPYRIGHT
#    Fully protected under Berne Convention, use authorized except
#    if you make money from this use (contact me before).
# DESCRIPTION
#    This script creates message files from the text file MESSAGES.
#    The generated files are modem-type specific files.
# NOTES
#    - Might need a patched rsynth.
#    - Needs ksh or bash.
#    - Might need to adjust the paths.
#    - New conversion commands based on voice/scripts/speakdate.sh
# BUGS
#    - Might be Linux specific.
#    - Looks hackish. It is.
# TODO

if [ $# != 0 ]; then
   echo "$0"
   echo "$0: bad args."
   exit 2
fi

# Next four lines are installation-specific and are corrected by setup.sh
PVF_TOOLS_DIR=/users/schaefer/ported/mgetty/mgetty-0.99.4/voice/pvftools/
SAY_RSYNTH_EXECUTABLE=/users/schaefer/ported/rsynth/say
PVF_MODEM_FILTER=pvftozyxel4
MGETTY_ZYXEL_2864_HACK1='echo -n RMD1ZyXEL 2864'
MGETTY_ZYXEL_2864_HACK2='dd bs=14 skip=1'

# Don't change anything from here.
# BUGS
#    - See the ZyXEL hack below.
export MESSAGES=MESSAGES

function say_something {
   rm -f tmp
   touch tmp
   $SAY_RSYNTH_EXECUTABLE -r 9600 -L "$1" > /dev/null
   cat tmp | $PVF_TOOLS_DIR/lintopvf | $PVF_TOOLS_DIR/pvfcut -0.5 -0.5 | $PVF_TOOLS_DIR/pvfamp 3.5 | $PVF_TOOLS_DIR/$PVF_MODEM_FILTER | ($MGETTY_ZYXEL_2864_HACK1; $MGETTY_ZYXEL_2864_HACK2) > $2
   rm tmp
}

echo "$0"
echo ""
echo -n "Generating messages ..."

cat $MESSAGES | ( while :
                  do
                     read Line
                     if [ $? != 0 ]; then
                        break
                     fi
                     set - $Line
                     WHERE=$1
                     shift
                     Line="$*"
                     echo "$WHERE "
                     if [ -f $WHERE ]; then
                        mv $WHERE $WHERE.DIS
                     fi
                     say_something "$Line" `pwd`/$WHERE
                  done
                )
echo ""
