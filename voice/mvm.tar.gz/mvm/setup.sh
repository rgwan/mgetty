#! /bin/sh
# setup.sh -- Setups the minimal voicemail system
# Marc SCHAEFER <schaefer@alphanet.ch>
# Creation: 11/07/96
# Update:   06/04/97
# V1.0 PV005
# DESCRIPTION
# NOTES
# BUGS
# TODO

INSTALL_DIR=/usr/lib/mgetty
SPOOL_DIR=/usr/spool/voice

#INSTALL_DIR=/tmp/abcd/mgetty
#SPOOL_DIR=/tmp/abcd/voice

cat << FINTRUC
Welcome to the Minimal Voicemail System version 1.0
Author: Marc SCHAEFER <schaefer@alphanet.ch>

# DISCLAIMER
#    No warranty, either expressed or implied.
# COPYRIGHT
#    Fully protected under Berne Convention, use authorized except
#    if you make money from this use (contact me before).

FINTRUC

echo ""
echo -n "Did you read the README ?: "

read Answer
case $Answer in
   y|Y|YES|yes|Yes) ;;
   *)               echo "It is time to do so."
                    exit 1;;
esac

echo ""
echo "I will install files in ${INSTALL_DIR} and in"
echo "${SPOOL_DIR}. I suggest you make a backup copy of"
echo "your old ${INSTALL_DIR} directory. You by the"
echo "way need approximately one megabyte in ${SPOOL_DIR},"
echo "much less in ${INSTALL_DIR}."
echo ""
echo -n "Ok to proceed ?: "

read Answer
case $Answer in
   y|Y|yes|YES|Yes) ;;
   *)               echo "Installation Aborted."
                    exit 1;;
esac

echo ""
echo "I need to know which device you use for your getty."
echo "Possible answers are e.g. ttyS0 or ttyS1."
echo -n "mgetty device [/dev/ttyS0] ?: "
read MGETTY_DEVICE

if [ "$MGETTY_DEVICE" = "" ]; then
   MGETTY_DEVICE=/dev/ttyS0
fi

case $MGETTY_DEVICE in
   /dev/tty*) ;;
   tty*) MGETTY_DEVICE="/dev/${MGETTY_DEVICE}";;
   *) echo "Please read mgetty's README."
      exit 1;;
esac

echo ""
echo "Where is your mgetty software voice directory ?"
echo -n "mgetty voice directory [/users/schaefer/ported/mgetty/mgetty-0.99.4/voice] ?:"
read MGETTY_VOICE_DIRECTORY
if [ "$MGETTY_VOICE_DIRECTORY" = "" ]; then
   MGETTY_VOICE_DIRECTORY=/users/schaefer/ported/mgetty/mgetty-0.99.4/voice
fi

echo ""
echo "I need to know what is your pvftoMODEM executable."
echo "Possible answers are e.g. pvftozyxel4 for 2864 ZyXEL."
echo "Look in $MGETTY_VOICE_DIRECTORY/pvftools."
echo -n "Executable for pvftomodem conversion [pvftozyxel4] ?: "
read MGETTY_PVFUTIL
if [ "$MGETTY_PVFUTIL" = "" ]; then
   MGETTY_PVFUTIL=pvftozyxel4
fi

echo ""
echo -n "Do you have a 2864 ZyXEL [y] ?:"
read MGETTY_ZYXEL_2864_HACK
if [ "$MGETTY_ZYXEL_2864_HACK" = "" ]; then
   MGETTY_ZYXEL_2864_HACK=y
fi
case $MGETTY_ZYXEL_2864_HACK in
   y*|Y) MGETTY_ZYXEL_2864_HACK1='"echo -n RMD1ZyXEL 2864"'
         MGETTY_ZYXEL_2864_HACK2='"dd bs=14 skip=1"';;
   *) MGETTY_ZYXEL_2864_HACK1='cat'
      MGETTY_ZYXEL_2864_HACK2='test';;
esac

echo ""
echo "Where is your say command (from rsynth) ?"
echo "If not specified, there will be missing functionnality."
echo "NOTE: this script expects a hacked rsynth, so if you did"
echo "      not hack it, use the default."
echo -n "RSYNTH's say is in [OLD_BINS/say] ?: "
read MGETTY_RSYNTH_SAY
if [ "$MGETTY_RSYNTH_SAY" = "" ]; then
   MGETTY_RSYNTH_SAY=OLD_BINS/say
fi

echo ""
echo "Where is your randomize command ?"
echo "If not specified, there will be missing functionnality."
echo -n "randomize is in [OLD_BINS/randomize] ?: "
read MGETTY_RANDOMIZE
if [ "$MGETTY_RANDOMIZE" = "" ]; then
   MGETTY_RANDOMIZE=OLD_BINS/randomize
fi

echo ""
echo -n "Random file library path [/share/archives/sounds/diverse] ?:"
read MGETTY_LIBRARY_PATH
if [ "$MGETTY_LIBRARY_PATH" = "" ]; then
   MGETTY_LIBRARY_PATH=/share/archives/sounds/diverse
fi

echo ""
echo "Making directories ..."

mkdir -p ${INSTALL_DIR} ${SPOOL_DIR}

echo ""
echo -n "Installing files in ${INSTALL_DIR} ..."

for i in $MGETTY_RSYNTH_SAY $MGETTY_RANDOMIZE
do
   case $i in
      OLD_BINS/*) cp $i ${INSTALL_DIR};;
   esac
done

case $MGETTY_RSYNTH_SAY in
   OLD_BINS/*) MGETTY_RSYNTH_SAY=${INSTALL_DIR}/say;;
esac

case $MGETTY_RANDOMIZE in
   OLD_BINS/*) MGETTY_RANDOMIZE=${INSTALL_DIR}/randomize;;
esac

cat voice_script.sh | sed "s%^PVF_TOOLS_DIR=.*%PVF_TOOLS_DIR=$MGETTY_VOICE_DIRECTORY/pvftools%
                           s%^SAY_RSYNTH_EXECUTABLE=.*%SAY_RSYNTH_EXECUTABLE=$MGETTY_RSYNTH_SAY%
                           s%^PVF_MODEM_FILTER=.*%PVF_MODEM_FILTER=$MGETTY_PVFUTIL%
                           s%^SELECT_RANDOM_FILE=.*%SELECT_RANDOM_FILE=$MGETTY_RANDOMIZE%
                           s%^LIBRARY_DIR=.*%LIBRARY_DIR=$MGETTY_LIBRARY_PATH%
                           s%^MGETTY_ZYXEL_2864_HACK1=.*%MGETTY_ZYXEL_2864_HACK1=$MGETTY_ZYXEL_2864_HACK1%
                           s%^MGETTY_ZYXEL_2864_HACK2=.*%MGETTY_ZYXEL_2864_HACK2=$MGETTY_ZYXEL_2864_HACK2%" > ${INSTALL_DIR}/voice_script.sh

cat mgetty.config | sed "s%^port ttyS0.*%port `basename $MGETTY_DEVICE`%" > ${INSTALL_DIR}/mgetty.config

cat voice.conf | sed "s%^port ttyS0.*%port `basename $MGETTY_DEVICE`%
                      s%call_program /usr/lib/mgetty/voice_script.sh.*%call_program ${INSTALL_DIR}/voice_script.sh%
                      s%^voice_devices ttyS0.*%voice_devices `basename $MGETTY_DEVICE`%" > ${INSTALL_DIR}/voice.conf

echo "ok"
echo -n "Installing files in ${SPOOL_DIR} ..."
cp -r voice/* ${SPOOL_DIR}
echo "ok"

echo "Generating prompts in ${SPOOL_DIR}/messages ..."
mkdir -p ${SPOOL_DIR}/messages
cp MESSAGES ${SPOOL_DIR}/messages
sed < generate_messages.sh "s%^PVF_MODEM_FILTER=.*%PVF_MODEM_FILTER=$MGETTY_PVFUTIL%
                   s%^PVF_TOOLS_DIR=.*%PVF_TOOLS_DIR=$MGETTY_VOICE_DIRECTORY/pvftools%
                   s%^SAY_RSYNTH_EXECUTABLE=.*%SAY_RSYNTH_EXECUTABLE=$MGETTY_RSYNTH_SAY%
             s%^SELECT_RANDOM_FILE=.*%SELECT_RANDOM_FILE=$MGETTY_RANDOMIZE%
                   s%^MGETTY_ZYXEL_2864_HACK1=.*%MGETTY_ZYXEL_2864_HACK1=$MGETTY_ZYXEL_2864_HACK1%
                   s%^MGETTY_ZYXEL_2864_HACK2=.*%MGETTY_ZYXEL_2864_HACK2=$MGETTY_ZYXEL_2864_HACK2%
             s%^LIBRARY_DIR=.*%LIBRARY_DIR=$MGETTY_LIBRARY_PATH%" > ${SPOOL_DIR}/messages/generate.sh
cd ${SPOOL_DIR}/messages
chmod 700 generate.sh
./generate.sh

echo ""
echo "Updating permissions"
chown -R root.root ${INSTALL_DIR}
chown -R root.root ${SPOOL_DIR}

echo ""
echo "Installation complete."

